<?php

namespace Wpe_Content_Engine\Helper\Constants;

class Order_By {

	public const ID       = 'id';
	public const DATE     = 'date';
	public const MODIFIED = 'modified';
}
