<?php

namespace Wpe_Content_Engine\Helper\Constants;

class GraphQL_Type {

	public const INTEGER = 'Int';
	public const STRING  = 'String';

}
