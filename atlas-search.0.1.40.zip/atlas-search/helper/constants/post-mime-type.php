<?php

namespace Wpe_Content_Engine\Helper\Constants;

class Post_Mime_Type {

	public const IMAGE = 'image';
}
