<?php

namespace Wpe_Content_Engine\Helper\Constants;

class Post_Type {

	public const POST       = 'post';
	public const PAGE       = 'page';
	public const ATTACHMENT = 'attachment';
}
