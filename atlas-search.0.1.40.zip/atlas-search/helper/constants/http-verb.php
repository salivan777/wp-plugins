<?php

namespace Wpe_Content_Engine\Helper\Constants;

class Http_Verb {

	public const POST = 'POST';
}
