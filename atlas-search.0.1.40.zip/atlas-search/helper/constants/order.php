<?php
 namespace Wpe_Content_Engine\Helper\Constants;

class Order {

	public const ASCENDING = 'ASC';
}
