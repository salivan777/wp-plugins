<?php

namespace Wpe_Content_Engine\Helper\Logging;

interface Logger {
	/**
	 * @param any $log Any object to log.
	 */
	public function log( $log );
}
