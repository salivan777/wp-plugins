<?php


namespace Wpe_Content_Engine\Helper;

class Asset_Type {

	public const AVATAR         = 'avatar';
	public const FEATURED_IMAGE = 'featured_image';
}
