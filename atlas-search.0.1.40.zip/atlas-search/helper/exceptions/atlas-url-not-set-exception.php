<?php

namespace Wpe_Content_Engine\Helper\Exceptions;

class AtlasUrlNotSetException extends \ErrorException {}
