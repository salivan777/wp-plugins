<?php

namespace Wpe_Content_Engine\Helper\Sync\Batches\Options;

abstract class Sync_Lock_State {

	const STOPPED = 'stopped';
	const RUNNING = 'running';
}
