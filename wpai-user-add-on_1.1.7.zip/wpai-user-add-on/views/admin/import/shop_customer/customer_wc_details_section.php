<div class="wpallimport-collapsed closed">
	<div class="wpallimport-content-section">
		<div class="wpallimport-collapsed-header">
			<h3><?php _e('Billing & Shipping Info','wpai_woocommerce_addon_plugin');?></h3>	
		</div>
		<div class="wpallimport-collapsed-content" style="padding:0;">
            <div class="wpallimport-collapsed-content-inner">
                <div class="pmsci-customer-fields">
                    <div id="pmsci_billing">

                        <!-- BILLING -->

                        <?php include( '_tabs/_customer_billing.php' ); ?>

                    </div>
                    <div id="pmsci_shipping">

                        <!-- SHIPPING -->

                        <?php include( '_tabs/_customer_shipping.php' ); ?>

                    </div>
                    <div class="clear"></div>
                </div>
            </div>
		</div>
	</div>
</div>