<!-- WooCommerce Customer Personal Section -->

<?php include( 'customer_personal_section.php' ); ?>

<!-- WooCommerce Customer Details Section -->

<?php include( 'customer_wc_details_section.php' ); ?>

<!-- Other Customer Details Section -->

<?php include( 'customer_other_section.php' ); ?>