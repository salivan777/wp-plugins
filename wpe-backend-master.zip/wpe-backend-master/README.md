# WP Engine backend
A WordPress and Docker setup for WP Engine backend local environment

## Local Install
### .env file

Copy the `.env.example` file and rename it to `.env`.

### The "docker" Folder
Put into the `/docker/db` folder the latest sql dump of the project, the dump file should be named `latest.sql`. If you want a fresh install you can use an empty `latest.sql` file.

### Other Plugins
The docker setup already installs some plugins. You can see the list or add new plugins in the `/docker/install_wordpress.sh` file. If you need plugins, that can't be installed this way, you can either install them from the admin dashboard when docker is up and running or download your plugins and put the extracted plugin folder in `/wordpress/wp-content/plugins`.

If any of the required plugins are not installed automatically, please include them in the following list:
- Advanced Custom Fields Pro (Contact alex@drewl.com)
- [WPGraphQL Content Blocks](https://github.com/wpengine/wp-graphql-content-blocks)
- [WPGraphQL for ACF](https://github.com/wp-graphql/wp-graphql-acf)
- [WPGraphQL Polylang](https://github.com/valu-digital/wp-graphql-polylang)

### Start Using Docker
Use the commande line `docker-compose up` to start using docker. Your project should be available at http://localhost:8080. Your admin login and password are the ones you set in your `.env` file.
