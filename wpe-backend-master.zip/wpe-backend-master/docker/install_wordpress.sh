#!/usr/bin/env sh

set -e

# Checking MYSQL is ready to be used.
mysql_ready='nc -z db-wpengine 3306'

if ! $mysql_ready
then
    printf 'Waiting for MySQL.'
    while ! $mysql_ready
    do
        printf '.'
        sleep 1
    done
    echo
fi


if wp core is-installed
then
    echo "WordPress is already installed, exiting."
    exit
fi



wp core download --force

[ -f wp-config.php ] || wp config create \
    --dbhost="$WORDPRESS_DB_HOST" \
    --dbname="$WORDPRESS_DB_NAME" \
    --dbuser="$WORDPRESS_DB_USER" \
    --dbpass="$WORDPRESS_DB_PASSWORD" \
    --dbprefix="$WORDPRESS_DB_PREFIX"


wp core install \
    --url="$WORDPRESS_URL" \
    --title="$WORDPRESS_TITLE" \
    --admin_user="$WORDPRESS_ADMIN_USER" \
    --admin_password="$WORDPRESS_ADMIN_PASSWORD" \
    --admin_email="$WORDPRESS_ADMIN_EMAIL" \
    --skip-email

wp option update blogdescription "$WORDPRESS_DESCRIPTION"

wp rewrite structure "$WORDPRESS_PERMALINK_STRUCTURE"

wp theme activate $THEME_NAME

wp theme delete twentytwenty twentytwentyone twentytwentytwo twentytwentythree

wp plugin delete akismet hello
wp plugin install --activate --force \
    custom-post-type-ui \
    wordpress-seo \
    advanced-custom-fields \
    wp-graphql \
    faustwp \
    atlas-search \
    polylang \
    add-wpgraphql-seo \

if [ -z "$MIGRATEDB_FROM" ]
then
    echo "No source installation specified. Please set MIGRATEDB_FROM in the .env file."
    exit
fi

echo "About to run data migration from $MIGRATEDB_FROM"

wp db import $MIGRATEDB_FROM

wp option update siteurl "$WORDPRESS_URL"
wp option update home "$WORDPRESS_URL"

wp rewrite flush



echo "Great. You can now log into WordPress at: $WORDPRESS_URL/wp-admin ($WORDPRESS_ADMIN_USER/$WORDPRESS_ADMIN_PASSWORD)"
