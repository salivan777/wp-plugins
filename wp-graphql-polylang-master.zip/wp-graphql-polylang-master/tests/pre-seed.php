<?php

define('PLL_ADMIN', true);
define('PLL_SETTINGS', true);
