<?php
require_once __DIR__ . '/../../.wp-install/vendor/autoload.php';
define('GRAPHQL_DEBUG', true);
define('GRAPHQL_POLYLANG_TESTS', true);
