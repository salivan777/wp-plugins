See <https://github.com/valu-digital/wp-graphql-polylang/releases>
