jQuery( function ( $ ) {
    if ( jQuery( '.rp4wp-configurator' ) ) {
        new RP4WP_Configurator( jQuery( '.rp4wp-configurator-wrapper' ) );
    }
} );