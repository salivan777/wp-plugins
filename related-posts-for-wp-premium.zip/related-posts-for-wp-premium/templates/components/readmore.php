<a href="<?php echo get_permalink( $related_post->ID ); ?>"><?php echo esc_html( $custom ); ?></a>
