<span><?php echo date_i18n( get_option( 'date_format' ), strtotime( $related_post->post_date ) ); ?></span>
