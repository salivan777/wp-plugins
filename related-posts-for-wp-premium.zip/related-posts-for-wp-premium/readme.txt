=== Related Posts for WordPress Premium ===
Contributors: never5, barrykooij
Donate link: http://www.relatedpostsforwp.com/
Tags: related posts for wordpress, related posts for wp, simple related posts, easy related posts, related posts, related, relations, internal links, seo, bounce rate
Requires at least: 3.8
Tested up to: 5.0.3
Stable tag: 1.9.0
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Display related posts without slowing down your website! Link all your existing content with only 1 click, get related posts for all your posts today!

== Description ==

= Related Posts for WordPress =

Related Posts for WordPress offers you the ability to link related posts to each other with just 1 click!

== Installation ==

= Installing the plugin =
1. In your WordPress admin panel, go to *Plugins > New Plugin*, search for *Related Posts for WordPress* and click "Install now"
1. Alternatively, download the plugin and upload the contents of `related-posts-for-wp.zip` to your plugins directory, which usually is `/wp-content/plugins/`.
1. Activate the plugin
