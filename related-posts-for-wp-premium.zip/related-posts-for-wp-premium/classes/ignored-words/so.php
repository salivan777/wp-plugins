<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

return array( "aad",  "albaabkii",  "atabo",  "ay",  "ayaa",  "ayee",  "ayuu",  "dhan",  "hadana",  "in",  "inuu",  "isku",  "jiray",  "jirtay",  "ka",  "kale",  "kasoo",  "ku",  "kuu",  "lakin",  "markii",  "oo",  "si",  "soo",  "uga",  "ugu",  "uu",  "waa",  "waxa",  "waxuu", );