<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

return array( "akasema",  "alikuwa",  "alisema",  "baada",  "basi",  "bila",  "cha",  "chini",  "hadi",  "hapo",  "hata",  "hivyo",  "hiyo",  "huku",  "huo",  "ili",  "ilikuwa",  "juu",  "kama",  "karibu",  "katika",  "kila",  "kima",  "kisha",  "kubwa",  "kutoka",  "kuwa",  "kwa",  "kwamba",  "kwenda",  "kwenye",  "la",  "lakini",  "mara",  "mdogo",  "mimi",  "mkubwa",  "mmoja",  "moja",  "muda",  "mwenye",  "na",  "naye",  "ndani",  "ng",  "ni",  "nini",  "nonkungu",  "pamoja",  "pia",  "sana",  "sasa",  "sauti",  "tafadhali",  "tena",  "tu",  "vile",  "wa",  "wakati",  "wake",  "walikuwa",  "wao",  "watu",  "wengine",  "wote",  "ya",  "yake",  "yangu",  "yao",  "yeye",  "yule",  "za",  "zaidi",  "zake", );