<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

return array( "futhi",  "kahle",  "kakhulu",  "kanye",  "khona",  "kodwa",  "kungani",  "kusho",  "la",  "lakhe",  "lapho",  "mina",  "ngesikhathi",  "nje",  "phansi",  "phezulu",  "u",  "ukuba",  "ukuthi",  "ukuze",  "uma",  "wahamba",  "wakhe",  "wami",  "wase",  "wathi",  "yakhe",  "zakhe",  "zonke", );