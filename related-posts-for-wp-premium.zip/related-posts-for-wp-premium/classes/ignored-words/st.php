<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

return array( "a",  "ba",  "bane",  "bona",  "e",  "ea",  "eaba",  "empa",  "ena",  "ha",  "hae",  "hape",  "ho",  "hore",  "ka",  "ke",  "la",  "le",  "li",  "me",  "mo",  "moo",  "ne",  "o",  "oa",  "re",  "sa",  "se",  "tloha",  "tsa",  "tse", );