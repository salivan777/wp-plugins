<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

return array( "a",  "amma",  "ba",  "ban",  "ce",  "cikin",  "da",  "don",  "ga",  "in",  "ina",  "ita",  "ji",  "ka",  "ko",  "kuma",  "lokacin",  "ma",  "mai",  "na",  "ne",  "ni",  "sai",  "shi",  "su",  "suka",  "sun",  "ta",  "tafi",  "take",  "tana",  "wani",  "wannan",  "wata",  "ya",  "yake",  "yana",  "yi",  "za", );