<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

return array( "aga",  "ei",  "et",  "ja",  "jah",  "kas",  "kui",  "kõik",  "ma",  "me",  "mida",  "midagi",  "mind",  "minu",  "mis",  "mu",  "mul",  "mulle",  "nad",  "nii",  "oled",  "olen",  "oli",  "oma",  "on",  "pole",  "sa",  "seda",  "see",  "selle",  "siin",  "siis",  "ta",  "te",  "ära", );