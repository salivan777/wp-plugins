<?php

return array(
	'admin_scripts',
	'ajax_delete_link',
	'ajax_install_link_posts',
	'ajax_install_save_options',
	'ajax_install_save_words',
	'ajax_install_set_post_types',
	'ajax_install_relink',
	'ajax_install_reinstall',
	'delete_words',
	'frontend_css',
	'link_related_screen',
	'meta_box',
	'meta_box_ajax_sort',
	'meta_box_options',
	'page_install',
	'post_type',
	'related_auto_link',
	'related_update_link',
	'related_save_words',
	'save_meta_box_options',
	'settings_page',
	'shortcode',
	'thumbnail',
	'widget'
);