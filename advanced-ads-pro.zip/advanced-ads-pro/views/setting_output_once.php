<hr/>
<label for="advads-output-once" class="label"><?php _e( 'Display only once', 'advanced-ads-pro' ); ?></label>
<div>
<input id="advads-output-once" type="checkbox" name="advanced_ad[output][once_per_page]" value="1" <?php checked( $once_per_page, 1);  ?> />
<?php _e( 'Display the ad only once per page', 'advanced-ads-pro' ); ?>
</div>