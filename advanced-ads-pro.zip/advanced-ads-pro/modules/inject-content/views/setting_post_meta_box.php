<br />
<label><input type="checkbox" name="advanced_ads[disable_the_content]" value="1" <?php
if ( isset( $values['disable_the_content'] ) ) { checked( $values['disable_the_content'], true ); }
?>/><?php _e( 'Disable automatic ad injection into the content', 'advanced-ads-pro' ); ?></label>