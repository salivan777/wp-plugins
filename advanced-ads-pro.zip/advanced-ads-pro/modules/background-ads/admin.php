<?php

new Advanced_Ads_Pro_Module_Background_Ads_Admin();

