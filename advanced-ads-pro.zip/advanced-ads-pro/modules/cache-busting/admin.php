<?php

new Advanced_Ads_Pro_Module_Cache_Busting_Admin;
