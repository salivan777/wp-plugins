#!/bin/sh

/public/bin/wp-cli.phar "$@"