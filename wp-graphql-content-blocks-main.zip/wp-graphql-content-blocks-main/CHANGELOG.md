# WPGraphQL Content Blocks

## 0.1.0

- Proof of concept.
